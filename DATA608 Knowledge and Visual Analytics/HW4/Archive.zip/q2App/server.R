library(shiny)
library(dplyr)
library(ggplot2)
library(forcats)



shinyServer(function(input, output) {
  output$distPlot <- renderPlot({
    
    cdcData <- read.csv("https://raw.githubusercontent.com/charleyferrari/CUNY_DATA608/master/lecture3/data/cleaned-cdc-mortality-1999-2010-2.csv")
    totalPopulation <- sum(as.numeric(unique(cdcData$Population)))
    #create national data
    #natAvg <- cdcData %>%
    #  group_by(Year) %>%
    #  summarise(totDeaths = sum(as.numeric(Deaths)), totPopulation = sum(as.numeric(Population)), totCrude.Rate = (sum(as.numeric(Population)/totalPopulation)))
      
    natAvg <- cdcData %>%
      group_by(Year, ICD.Chapter) %>%
      summarise(totDeaths = sum(as.numeric(Deaths)), totPopulation = sum(as.numeric(Population)), Crude.Rate = sum((as.numeric(Population)/totPopulation)*as.numeric(Crude.Rate))) %>%
      group_by(Year) %>%
      mutate(maxTotPop = max(totPopulation)) %>% #ensure yearly total population is universal (some states likely missed death types)
      mutate(State = "NL") %>%
      filter(ICD.Chapter == input$causes) %>%
      select(State, ICD.Chapter, Crude.Rate, Year)
    
    testStatesCauses <- cdcData %>%
      filter(State == input$states, ICD.Chapter == input$causes) %>%
      select(State, ICD.Chapter, Crude.Rate, Year)
    #testStatesCauses$State <- lapply(testStatesCauses$State, as.character)
    #natAvg$State <- lapply(natAvg$State, as.character)
    nationalAndStates <-bind_rows(natAvg, testStatesCauses)
    
    
    #filter data by year and cause
    #chosenStatesCauses <- cdcData %>%
    #  filter(State == input$states, ICD.Chapter == input$causes) %>%
    #  select(State, ICD.Chapter, Crude.Rate, Year)
    
    
    ggplot(nationalAndStates, aes(x = Year, y = Crude.Rate, colour = State)) + geom_line()
  })
})