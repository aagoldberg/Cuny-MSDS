library(shiny)

shinyUI(fluidPage(
  
  sidebarLayout(
    sidebarPanel(
      selectInput("causes",
                  "Cause of death:",
                  choices = unique(cdcData$ICD.Chapter)),
      selectInput("states",
                  "State:",
                  choices = unique(cdcData$State))
    ),

    mainPanel(
      plotOutput("distPlot")
    )
  )
))